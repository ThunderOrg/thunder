<?php
   require_once("scripts/CARECloud.php");
   $authorization->Logout();
?>
