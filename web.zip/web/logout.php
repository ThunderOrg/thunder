<?php
   require_once("scripts/thunder.php");
   $authorization->Logout();
?>
