<?php
$passhash = hash("sha256", "admin");
echo $passhash
?>
